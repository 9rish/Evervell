import 'package:flutter/material.dart';
import 'package:healthcare/screens/welcome_screen.dart';
import 'package:healthcare/screens/login_screen.dart';
import 'package:healthcare/screens/sign_up_screen.dart';
import 'package:healthcare/widgets/navbar_roots.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:timezone/data/latest.dart' as tz;  // Add timezone import
import 'package:timezone/timezone.dart' as tz; 

// void main() async {
//   await Supabase.initialize(
//     url: 'https://pjvfeksymzceqkkhibmf.supabase.co',
//     anonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InBqdmZla3N5bXpjZXFra2hpYm1mIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MjkyNjAzNTIsImV4cCI6MjA0NDgzNjM1Mn0.7UbvsYwAIJHQIoFazvkMFSEPxEwpWMCXeB-imfI0AJQ',
//   );
//   runApp(MyApp());
// }

// class MyApp extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       home: SignInScreen(),
//     );
//   }
// }

// class SignInScreen extends StatefulWidget {
//   @override
//   _SignInScreenState createState() => _SignInScreenState();
// }

// class _SignInScreenState extends State<SignInScreen> {
//   final TextEditingController _emailController = TextEditingController();
//   final TextEditingController _passwordController = TextEditingController();

//   Future<void> signInUser() async {
//     try {
//       final AuthResponse res = await Supabase.instance.client.auth.signInWithPassword(
//         email: _emailController.text.trim(),
//         password: _passwordController.text.trim(),
//       );
//       final Session? session = res.session;
//       final User? user = res.user;

//       if (user != null) {
//         print('User signed in: ${user.email}');
//         // You can navigate to another screen here
//       } else {
//         print('No user found');
//       }
//     } catch (e) {
//       print('Error signing in: $e');
//     }
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text('Sign In'),
//       ),
//       body: Padding(
//         padding: const EdgeInsets.all(16.0),
//         child: Column(
//           children: [
//             TextField(
//               controller: _emailController,
//               decoration: InputDecoration(
//                 labelText: 'Email',
//               ),
//             ),
//             TextField(
//               controller: _passwordController,
//               obscureText: true,
//               decoration: InputDecoration(
//                 labelText: 'Password',
//               ),
//             ),
//             SizedBox(height: 20),
//             ElevatedButton(
//               onPressed: signInUser,
//               child: Text('Sign In'),
//             ),
//           ],
//         ),
//       ),
//     );
//   }

//   @override
//   void dispose() {
//     _emailController.dispose();
//     _passwordController.dispose();
//     super.dispose();
//   }
// }


Future<void> main() async {
  // Ensures that widget binding is initialized before running the app
  WidgetsFlutterBinding.ensureInitialized();

  // Initialize Supabase without `authFlowType`
  await Supabase.initialize(
    url: 'https://pjvfeksymzceqkkhibmf.supabase.co', // Replace with your Supabase URL
    anonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InBqdmZla3N5bXpjZXFra2hpYm1mIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MjkyNjAzNTIsImV4cCI6MjA0NDgzNjM1Mn0.7UbvsYwAIJHQIoFazvkMFSEPxEwpWMCXeB-imfI0AJQ', // Replace with your Supabase anon key
    realtimeClientOptions: const RealtimeClientOptions(
      logLevel: RealtimeLogLevel.info,
    ),
    storageOptions: const StorageClientOptions(
      retryAttempts: 10,
    ),
  );
  // Initialize the timezone package
  tz.initializeTimeZones();  // Initialize timezone data

  // Run the app
  runApp(const MyApp());
}

class MyApp extends StatelessWidget 
{
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Healthcare App',
      initialRoute: '/',
      routes: {
        '/': (context) => const WelcomeScreen(),
        '/login': (context) => LoginScreen(),
        '/signup': (context) => SignUpPage(),
        '/home': (context) => const NavBarRoots(),
      },
    );
  }
}
