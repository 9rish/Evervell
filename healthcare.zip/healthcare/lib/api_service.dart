// lib/api_service.dart
import 'dart:convert';
import 'package:http/http.dart' as http;

const String API_KEY = 'your-api-key-here';  // Insert your OpenAI API key here

Future<String> fetchMedicationDetails(String content, DateTime currentDateTime) async {
  final String systemPrompt = '''
    Today’s date for context is ${convertUtcToIst(currentDateTime)}
    You are a helpful assistant. When the user request indicates setting a reminder, return an object with the following parameters:
    
    - `type`: If the request is to set a reminder, return "Reminder". Otherwise, return "Other".
    - `startDate`: If a start date and time are provided by the user, return them in ISO format. If only time is provided, return with today’s date and time. If not provided, return `""`.
    - `endDate`: If an end date and time are provided by the user, return them in ISO format. If not provided, return `""`.
    - `title`: Provide a suitable title for the reminder based on the user's request.
    - `notes`: Include any additional notes provided by the user.

    If the user's request does not indicate setting a reminder, return the following:
    
    {
      "type": "Other",
      "others": "additional parameters if any"
    }
  ''';

  final response = await http.post(
    Uri.parse('https://api.openai.com/v1/chat/completions'),
    headers: {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $API_KEY',
    },
    body: json.encode({
      'model': 'gpt-3.5-turbo-0125',
      'messages': [
        {'role': 'system', 'content': systemPrompt},
        {'role': 'user', 'content': content},
      ],
    }),
  );

  final Map<String, dynamic> data = jsonDecode(response.body);
  return data['choices'][0]['message']['content'];
}

String convertUtcToIst(DateTime dateTime) {
  return dateTime.toLocal().toIso8601String();
}
