import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

void main() async {
  // Ensure that Flutter is initialized
  WidgetsFlutterBinding.ensureInitialized();

  // Initialize Supabase with your project credentials
  await Supabase.initialize(
    url: 'https://pjvfeksymzceqkkhibmf.supabase.co',
    anonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InBqdmZla3N5bXpjZXFra2hpYm1mIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MjkyNjAzNTIsImV4cCI6MjA0NDgzNjM1Mn0.7UbvsYwAIJHQIoFazvkMFSEPxEwpWMCXeB-imfI0AJQ',
  );

  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Supabase Sign-Up',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: SignUpPage(),
    );
  }
}

class SignUpPage extends StatefulWidget {
  @override
  _SignUpPageState createState() => _SignUpPageState();
}

class _SignUpPageState extends State<SignUpPage> {
  // Initialize controllers
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  bool isLoading = false;
  String? errorMessage;

  // Function that handles user creation
  Future<bool> createUser({
    required String email,
    required String password,
  }) async {
    try {
      final response = await Supabase.instance.client.auth.signUp(
        email: email,
        password: password,
      );

      // Check if the user was successfully created
      if (response.user != null) 
      {
        // User successfully signed up
        print('User created: ${response.user!.email}');
        return true;
      } else {
        // Handle case where user is null
        throw Exception('Sign-up failed.'); // Throw an exception if user is null
      }
    } catch (e) {
      // Catch and display the error
      print('Error signing up: $e');
      setState(() {
        errorMessage = e.toString();
      });
      return false;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Sign Up'),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              TextField(
                controller: emailController,
                decoration: InputDecoration(
                  labelText: 'Email',
                ),
              ),
              TextField(
                controller: passwordController,
                obscureText: true,
                decoration: InputDecoration(
                  labelText: 'Password',
                ),
              ),
              SizedBox(height: 20),
              if (isLoading) CircularProgressIndicator(),
              if (errorMessage != null)
                Text(
                  errorMessage!,
                  style: TextStyle(color: Colors.red),
                ),
              ElevatedButton(
                onPressed: isLoading
                    ? null
                    : () async {
                        setState(() {
                          isLoading = true;
                          errorMessage = null;
                        });

                        // Validate email format
                        if (!RegExp(r'^[^@]+@[^@]+\.[^@]+').hasMatch(emailController.text.trim())) {
                          setState(() {
                            errorMessage = 'Please enter a valid email address.';
                            isLoading = false;
                          });
                          return;
                        }

                        await createUser(
                          email: emailController.text.trim(),
                          password: passwordController.text.trim(),
                        );
                        setState(() {
                          isLoading = false;
                        });
                      },
                child: Text('Create Account'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    emailController.dispose();
    passwordController.dispose();
    super.dispose();
  }
}
