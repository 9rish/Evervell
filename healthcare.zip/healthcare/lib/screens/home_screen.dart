import 'package:flutter/material.dart';
import 'package:healthcare/screens/appointment_screen.dart';
import 'package:healthcare/screens/schedule_screen.dart'; // Assuming this is the file for schedule
import 'package:healthcare/screens/medication_reminder_screen.dart'; // New reminder screen

class HomeScreen extends StatelessWidget {
  HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.only(top: 40),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 15),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "Welcome",
                    style: TextStyle(
                      fontSize: 35,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 40), // Space below the welcome message
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 15),
              child: Column(
                children: [
                  // Button to go to Schedule Screen
                  ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => const ScheduleScreen()),
                      );
                    },
                    child: const Text('View Schedule'),
                  ),
                  const SizedBox(height: 20), // Space between buttons
                  // Button to go to Medication Reminder Screen
                  ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => MedicationReminderScreen()),
                      );
                    },
                    child: const Text('Set Medication Reminders'),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
