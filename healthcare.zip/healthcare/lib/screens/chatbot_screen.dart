import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class ChatbotScreen extends StatefulWidget {
  const ChatbotScreen({super.key});

  @override
  _ChatbotScreenState createState() => _ChatbotScreenState();
}

class _ChatbotScreenState extends State<ChatbotScreen> {
  final TextEditingController _languageController = TextEditingController();
  final TextEditingController _genderController = TextEditingController();
  final TextEditingController _ageController = TextEditingController();
  String _response = "";

  Future<void> sendDiagnosisRequest(String language, List<String> gender, int age) async {
    final url = Uri.parse('http://127.0.0.1:5000/diagnose');  // Your server's IP
    final response = await http.post(
      url,
      headers: {"Content-Type": "application/json"},
      body: json.encode({
        "language": language,
        "gender": gender,
        "age": age
      }),
    );
    if (response.statusCode == 200) {
      setState(() {
        _response = json.decode(response.body)['response'];
      });
    } else {
      setState(() {
        _response = "Error connecting to server.";
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Chatbot Assistant")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _languageController,
              decoration: InputDecoration(labelText: "Enter language"),
            ),
            TextField(
              controller: _genderController,
              decoration: InputDecoration(labelText: "Enter gender"),
            ),
            TextField(
              controller: _ageController,
              decoration: InputDecoration(labelText: "Enter age"),
              keyboardType: TextInputType.number,
            ),
            ElevatedButton(
              onPressed: () {
                String language = _languageController.text;
                List<String> gender = [_genderController.text];
                int age = int.parse(_ageController.text);

                sendDiagnosisRequest(language, gender, age);
              },
              child: Text("Send"),
            ),
            SizedBox(height: 20),
            Text(
              _response,
              style: TextStyle(fontSize: 18),
            ),
          ],
        ),
      ),
    );
  }
}
