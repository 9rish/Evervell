import 'package:flutter/material.dart';
import 'package:intl/intl.dart'; // for formatting date and time
import 'package:healthcare/create_notification.dart'; // Ensure you have the correct import for notification service

class MedicationReminderScreen extends StatefulWidget {
  @override
  _MedicationReminderScreenState createState() => _MedicationReminderScreenState();
}

class _MedicationReminderScreenState extends State<MedicationReminderScreen> {
  final TextEditingController _reminderNameController = TextEditingController();
  DateTime? _selectedDate;
  TimeOfDay? _selectedTime;
  final List<Map<String, String>> _reminders = []; // Store reminders

  // Instance of NotificationService
  final NotificationService _notificationService = NotificationService();

  // Initialize notification service
  @override
  void initState() {
    super.initState();
    _notificationService.initialize(); // Initialize the notification service
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2020),
      lastDate: DateTime(2101),
    );
    if (picked != null && picked != _selectedDate) {
      setState(() {
        _selectedDate = picked;
      });
    }
  }

  Future<void> _selectTime(BuildContext context) async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
    );
    if (picked != null && picked != _selectedTime) {
      setState(() {
        _selectedTime = picked;
      });
    }
  }

  String _getFormattedDateTime() {
    if (_selectedDate != null && _selectedTime != null) {
      final DateTime dateTime = DateTime(
        _selectedDate!.year,
        _selectedDate!.month,
        _selectedDate!.day,
        _selectedTime!.hour,
        _selectedTime!.minute,
      );
      return DateFormat.yMMMd().add_jm().format(dateTime); // e.g., Oct 21, 2024, 11:46 AM
    }
    return 'No date and time selected';
  }

  void _addReminder() {
    if (_reminderNameController.text.isNotEmpty &&
        _selectedDate != null &&
        _selectedTime != null) {
      final String formattedDateTime = _getFormattedDateTime();
      print("Before adding: $_reminders"); // Print reminders before adding

      _reminders.add({
        'name': _reminderNameController.text,
        'datetime': formattedDateTime,
      });

      print("After adding: $_reminders"); // Print reminders after adding
      print("Reminder added: ${_reminders.last}"); // Print the last added reminder

      // Call the createNotificationReminder method
      _notificationService.createNotificationReminder(
        _reminderNameController.text,
        DateTime(
          _selectedDate!.year,
          _selectedDate!.month,
          _selectedDate!.day,
          _selectedTime!.hour,
          _selectedTime!.minute,
        ),
      );

      // Clear the input fields
      _reminderNameController.clear();
      setState(() {
        _selectedDate = null;
        _selectedTime = null;
      });
    } else {
      print("Please fill all fields!"); // Print message if fields are not filled
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Set Medication Reminder'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            TextField(
              controller: _reminderNameController,
              decoration: InputDecoration(labelText: 'Reminder Name'),
            ),
            SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  _selectedDate == null ? 'Select Reminder Date' : DateFormat.yMMMd().format(_selectedDate!),
                ),
                ElevatedButton(
                  onPressed: () => _selectDate(context),
                  child: Text('Choose Date'),
                ),
              ],
            ),
            SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  _selectedTime == null ? 'Select Reminder Time' : _selectedTime!.format(context),
                ),
                ElevatedButton(
                  onPressed: () => _selectTime(context),
                  child: Text('Choose Time'),
                ),
              ],
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _addReminder,
              child: Text('Set Reminder'),
            ),
            SizedBox(height: 20),
            Expanded(
              child: ListView.builder(
                itemCount: _reminders.length,
                itemBuilder: (context, index) {
                  final reminder = _reminders[index];
                  return ListTile(
                    title: Text(reminder['name']!),
                    subtitle: Text(reminder['datetime']!),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
