from flask import Flask, request, jsonify
from main import main  # Import your main function or class

app = Flask(__name__)

@app.route('/diagnose', methods=['POST'])
def diagnose():
    data = request.json  # Assuming you send JSON with necessary inputs
    language = data.get('language')
    gender = data.get('gender')
    age = data.get('age')

    # Call the main function and get the response
    response = main(language, gender, age)  # Adjust this based on how you defined the main function

    return jsonify({"response": response})

if __name__ == '__main__':
    app.run(debug=True)

#curl -X POST http://127.0.0.1:5000/diagnose -H "Content-Type: application/json" -d '{"language": "english", "gender": ["Male"], "age": "70"}'
