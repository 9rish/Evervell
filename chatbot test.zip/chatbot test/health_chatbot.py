import pandas as pd

# Load the CSV file
file_path = "your_health_data.csv"  # Replace with your CSV file path
health_data = pd.read_csv("C:\\Users\\sriak\\Downloads\\chatbot test\\user_conditions_info.csv")

def get_user_info(name):
    """Search for user in the CSV by name and return their info if found."""
    user_info = health_data[health_data['Name'].str.lower() == name.lower()]
    if not user_info.empty:
        return user_info
    else:
        return None

def update_health_data(name, symptoms, advice):
    """Update the health data with new symptoms and advice."""
    index = health_data[health_data['Name'].str.lower() == name.lower()].index
    health_data.at[index, 'Symptoms'] = symptoms
    health_data.at[index, 'Advice'] = advice
    health_data.to_csv(file_path, index=False)  # Save the updated data back to the CSV

def get_advice_based_on_symptoms(symptoms):
    """Provide health advice based on the symptoms."""
    advice_dict = {
        "fever": "You can take paracetamol or aspirin.",
        "headache": "You can take disprin.",
        "cough and cold": "You can take amoxicillin.",
        "diabetes": "You can take insulin lispro.",
        "stomach ache": "You can take panadol.",
        # Add more symptoms and advice here
    }
    advice = []
    for symptom in symptoms.split(','):
        symptom = symptom.strip().lower()
        if symptom in advice_dict:
            advice.append(advice_dict[symptom])
        else:
            advice.append("Please consult a healthcare professional.")
    return advice

def chatbot():
    print("Hello! I am your health care assistant. What is your name?")
    user_name = input("You: ").strip()
    
    user_info = get_user_info(user_name)
    if user_info is not None:
        print(f"Chatbot: Welcome back, {user_name}.")
        print("Chatbot: Please enter your current symptoms (comma-separated):")
        symptoms = input("You: ").strip()
        advice = get_advice_based_on_symptoms(symptoms)
        
        print(f"Chatbot: You have reported symptoms: {symptoms}.")
        print(f"Chatbot: Here is your advice: {', '.join(advice)}")

        # Update the CSV with new symptoms and advice
        update_health_data(user_name, symptoms, ', '.join(advice))

        follow_up = input("Chatbot: Would you like to ask anything else? (yes/no): ").strip().lower()
        if follow_up != 'yes':
            print("Chatbot: Goodbye! Stay healthy!")
        else:
            chatbot()  # Restart the conversation
    else:
        print("Chatbot: Sorry, I couldn't find your information in the database.")
        print("Chatbot: Please make sure you're registered or try again later.")

# Start the chatbot
chatbot()
