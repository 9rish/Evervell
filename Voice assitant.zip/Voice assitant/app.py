import os
from flask import Flask, render_template, request, redirect, url_for
import speech_recognition as sr
from gtts import gTTS
from playsound import playsound

app = Flask(__name__)

def command():
    with sr.Microphone() as source:
        r = sr.Recognizer()
        r.energy_threshold = 500
        audio = r.listen(source)
    try:
        return r.recognize_google(audio)
    except Exception as e:
        return "Sorry, I didn't catch that."

def assistant(word):
    health_advice = {
        "fever": "You can take paracetamol or aspirin. Thank you.",
        "headache": "You can take disprin. Thank you.",
        "cough": "You can take amoxicillin. Thank you.",
        # Add more conditions as needed
    }
    
    for condition in health_advice.keys():
        if condition in word.lower():
            response = health_advice[condition]
            text_to_speech = gTTS(text=response, lang='en')
            audio_file = 'audio.mp3'
            text_to_speech.save(audio_file)
            playsound(audio_file)
            return response
    return "I don't have information for that."

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/ask', methods=['POST'])
def ask():
    user_input = command()
    response = assistant(user_input)
    return render_template('index.html', user_input=user_input, response=response)

if __name__ == "__main__":
    app.run(debug=True)
